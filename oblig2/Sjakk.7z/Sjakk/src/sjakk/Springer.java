package sjakk;

/**
 *
 * @author speedy
 */
public class Springer {
    
}
