package sjakk;

/**
 *
 * @author speedy
 */
public class Dronning {
    
}
