package sjakk;

public class SjakkTest {

    public static void main(String[] args) {

        Brett b = new Brett(1);

        System.out.println(b.flyttBrikke("a2", "a4"));
    }
}
